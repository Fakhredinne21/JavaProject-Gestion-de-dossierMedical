public interface Consultable {
    public  void consulterDossier() throws DossierMedicalNotFoundException;
}
