import java.util.Scanner;

public class ModifierPatient implements Modifiable{
    Scanner in = new Scanner(System.in);
    private DossierMedical[] dossierMedicals;
    private int num_soc;
    private int nbd;

    public ModifierPatient(DossierMedical[] dossierMedicals, int num_soc, int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.num_soc = num_soc;
        this.nbd = nbd;
    }
    private int menu_chang() {

        System.out.println("Effecter des changement sur le patient");
        System.out.println("1. Changer Assurence maladie");
        System.out.println("2. Changer Numero de telephone");
        System.out.println("3. Changer Adresse");
        System.out.println("4. Changer nom");
        System.out.println("5. Changer prenom");
        System.out.println("6. Changer Numero de sécurité sociale");
        System.out.println("7. Quitter");
        int choix = in.nextInt();
        while (choix < 1 || choix > 7) {
            choix = in.nextInt();
        }
        return choix;
    }
    private void changement(int choix,int posPat){
        switch (choix) {
            case 1:
                String asr;
                asr=in.nextLine();
                System.out.println("Donner la nouvelle Assurance maladie:");
                asr=in.nextLine();
                dossierMedicals[posPat].getPatient().setAss_mal(asr);
                break;
            case 2:
                int num;
                System.out.println("Donner la nouvelle numero de tlf:");
                num=in.nextInt();
                dossierMedicals[posPat].getPatient().setTlf(num);
                break;
            case 3:
                String add;
                in.nextLine();
                System.out.println("Donner la nouvelle addresse:");
                add=in.nextLine();
                dossierMedicals[posPat].getPatient().setAdresse(add);
                break;

            case 4:
                String nom;
                in.nextLine();
                System.out.println("Donner la nouvelle nom:");
                nom=in.nextLine();
                dossierMedicals[posPat].getPatient().setNom(nom);
                break;
            case 5:
                String prenom;
                in.nextLine();
                System.out.println("Donner la nouvelle prenom:");
                prenom=in.nextLine();
                dossierMedicals[posPat].getPatient().setPrenom(prenom);
                break;

            case 6:

                int num_soc;
                System.out.println("Donner la nouvelle Numéro de sécurité sociale:");
                num_soc=in.nextInt();
                dossierMedicals[posPat].getPatient().setNum_sec_soc(num_soc);
                break;
            case 7:
                return;

        }
    }
    @Override
    public void ModifierDossier() throws DossierMedicalNotFoundException{
        int posPat=0;
        boolean exist=false;
        for (int i = 0; i < nbd&&dossierMedicals[i].getPatient().getNum_sec_soc()== num_soc; i++) {
            posPat=i;
            exist=true;
        }
        if(exist!=true){
            throw new DossierMedicalNotFoundException();
        }
        int choix = menu_chang();
        while (choix < 7) {
            if(choix==1){
                changement(choix,posPat);
            }

            choix = menu_chang();
        }
        System.out.println("Fin  de changement");


    }
}
