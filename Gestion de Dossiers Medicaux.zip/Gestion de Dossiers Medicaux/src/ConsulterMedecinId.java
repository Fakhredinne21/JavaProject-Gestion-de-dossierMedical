public class ConsulterMedecinId implements Consultable{
    private DossierMedical[] dossierMedicals;
    private int id;
    private int nbd;

    public ConsulterMedecinId(DossierMedical[] dossierMedicals, int id, int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.id = id;
        this.nbd = nbd;
    }

    @Override
    public void consulterDossier() throws DossierMedicalNotFoundException {
        boolean found=false;

        for (int i = 0; i <nbd&&!found ; i++) {
               if(dossierMedicals[i].getMedecin().getNum_id_pro()==id) {
                   found = true;
                   System.out.println(dossierMedicals[i].getPatient().toString());
               }
        }
        if(found==false){
            throw new DossierMedicalNotFoundException();
        }
    }
}
