public class DossierMedicalNotFoundException extends Exception{
    public DossierMedicalNotFoundException() {
    }

    @Override
    public String getMessage() {
        return "Le dossier n'est pas trouve";
    }
}
