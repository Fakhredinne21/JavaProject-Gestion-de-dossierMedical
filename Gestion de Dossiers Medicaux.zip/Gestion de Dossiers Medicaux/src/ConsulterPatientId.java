public class ConsulterPatientId implements Consultable{
      private DossierMedical[] dossierMedicals;
      private int num;
      private int nbd;
    public ConsulterPatientId(DossierMedical[] dossierMedicals, int num, int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.num = num;
        this.nbd = nbd;
    }


    @Override
    public void consulterDossier() throws DossierMedicalNotFoundException {
        boolean found=false;

        for (int i = 0; i <nbd &&!found; i++) {
            if(dossierMedicals[i].getPatient().getNum_sec_soc()==num){
                found=true;
                System.out.println(dossierMedicals[i].getPatient().toString());

            }


        }
        if(found==false){
            throw new DossierMedicalNotFoundException();
        }
    }
}
