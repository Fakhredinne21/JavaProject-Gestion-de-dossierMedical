public class ConsulterAdressePatient implements Consultable{
    private DossierMedical[] dossierMedicals;
    private String adresse;
    private int nbd;

    public ConsulterAdressePatient(DossierMedical[] dossierMedicals, String adresse, int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.adresse = adresse;
        this.nbd = nbd;
    }
    @Override
    public void consulterDossier() throws DossierMedicalNotFoundException{
        boolean found=false;
        for (int i = 0; i <nbd; i++) {
            if(dossierMedicals[i].getPatient().getAdresse().equals(this.adresse)){
                System.out.println(dossierMedicals[i].getPatient().toString());
                found=true;
            }


        }
        if(found==false){
            throw new DossierMedicalNotFoundException();
        }

    }
}
