import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class GestionDossierMedicaux {


   private  DossierMedical[] DossiersMedicaux;
  private int numD=0;
    private  Scanner scan=new Scanner(System.in);

   public GestionDossierMedicaux(int numD) {
      DossiersMedicaux = new DossierMedical[numD];
   }
   private Patient creerPatient(){
       System.out.println("Donner nom de patient:");
       String nom=scan.nextLine();
       System.out.println("Donner prenom de patient:");
       String prenom=scan.nextLine();
       LocalDate date=LocalDate.now();

       System.out.println("Donner adresse de patient:");
       String adr=scan.nextLine();
       System.out.println("Donner Assurance maladie de patient:");
       String assur=scan.nextLine();
       System.out.println("Donner num tlf de patient:");
       int tlf=scan.nextInt();
       Patient patient=new Patient(nom,prenom,date ,tlf,adr,assur);
       return patient;
   }
   private Medecin creerMedecin(){
       System.out.println("Donner nom de medecin:");
       String nom=scan.nextLine();
       System.out.println("Donner prenom de medecin:");
       String prenom=scan.nextLine();
       LocalDate date=LocalDate.now();
       System.out.println("Donner adresse de medecin:");
       String adr=scan.nextLine();
       System.out.println("Donner Spécialité de patient:");
       String spec=scan.nextLine();
       System.out.println("Donner num tlf de medecin:");
       int tlf=scan.nextInt();
       Medecin medecin=new Medecin(nom,prenom,date,tlf,adr,spec);
        return medecin;
   }
   public void creerDossierMedical(){
       Medecin med=null;
        scan.nextLine();
        Patient pat=creerPatient();
        scan.nextLine();
        System.out.println("Choisir un medecin deja existe ou nouvelle");
        int choix=scan.nextInt();
        if(choix==1){
            System.out.println("Donner id de medecin");
            int id=scan.nextInt();
            med=getMedecin(id);
            if(med==null){
                System.out.println("Medecin non trouver");
                creerDossierMedical();
            }

        }else if(choix==2){
            scan.nextLine();
            med=creerMedecin();
        }
        ArrayList sym=new ArrayList<>();
        ArrayList diag=new ArrayList<>();
        ArrayList medc=new ArrayList<>();
        DossierMedical dm=new DossierMedical(pat,sym,diag,medc,med);
        DossiersMedicaux[numD]=dm;
        numD++;
   }

    public DossierMedical[] getDossiersMedicaux() {
        return DossiersMedicaux;
    }

    public void consulterDossier(){
        int chc=0;
        System.out.println("Gestion des Dossiers");
        System.out.println("1. Consulter patients par adresse");
        System.out.println("2. Consulter patient par nom");
        System.out.println("3. Cosulter medecin par spec");
        System.out.println("4. Consulter patients par id");
        System.out.println("5. Consulter medecin par id");
        System.out.println("6. Consulter liste des patient");
        System.out.println("7. Consulter liste des medecins");
        System.out.println("Donner type de Consultation");
        chc=scan.nextInt();
        scan.nextLine();
        Consultable c = null;
        if(chc==1){
            System.out.println("Donner l'adresse");
            scan.nextLine();
            String add=scan.nextLine();
             c=new ConsulterAdressePatient(DossiersMedicaux,add,numD);
        }
        if(chc==2){
            System.out.println("Donner Nom de patient");
            String Nom=scan.nextLine();
            c=new ConsulterNomPatient(DossiersMedicaux,Nom,numD);
        }
        if(chc==3){
            System.out.println("Donner specialite de medecin");
            String spec=scan.nextLine();
            c=new ConsulterMedecinSpec(DossiersMedicaux,spec,numD);
        }
        if(chc==4){
            System.out.println("Donner specialite de medecin");
            int num=scan.nextInt();
            c=new ConsulterPatientId(DossiersMedicaux,num,numD);
        }
        if(chc==5){
            System.out.println("Donner id de medecin");
            int id=scan.nextInt();
            c=new ConsulterMedecinId(DossiersMedicaux,id,numD);
        }
        if (chc==6){
            c=new ConsulterListePatient(DossiersMedicaux,numD);
        }
        if (chc==7){
            c=new ConsulterListeMedecin(DossiersMedicaux,numD);
        }
        try{
            c.consulterDossier();
        }catch(DossierMedicalNotFoundException e){
            System.out.println(e.getMessage());
        }

  }
  public  void modifierDossier(){
        int chc=0;

        System.out.println("Gestion des Dossiers");
        System.out.println("1. Modifier information de traitment");
        System.out.println("2. Modifier patient");
        System.out.println("3. Modifier medecin");
        System.out.println("Donner type de modification");
        chc=scan.nextInt();
        Modifiable md = null;
        if(chc==3){
            System.out.println("Donner numero professionel de medecin");
            int modf=scan.nextInt();
             md=new modifierMedecin(DossiersMedicaux,modf,numD);
        }
        if(chc==2){
            System.out.println("Donner Numéro de sécurité sociale de patient");
            int numsoc=scan.nextInt();
             md=new ModifierPatient(DossiersMedicaux,numsoc,numD);

        }
      if(chc==1){
          System.out.println("Donner Numéro de sécurité sociale de patient");
          int numsoc=scan.nextInt();
           md=new ModifierPatient(DossiersMedicaux,numsoc,numD);

      }
      try{
          md.ModifierDossier();
      }catch (DossierMedicalNotFoundException e){
          e.getMessage();
      }

  }
    public boolean loginMedecin(int id) {
        for (int i = 0; i < numD; i++) {
            if(DossiersMedicaux[i].getMedecin().getNum_id_pro()==id){
                return true;
            }
        }
        return false;
    }
      public boolean loginPatient(int num) {
        for (int i = 0; i < numD; i++) {
            if(DossiersMedicaux[i].getPatient().getNum_sec_soc()==num){
                return true;
            }
        }
        return false;
    }
  public Medecin getMedecin(int id) {
      for (int i = 0; i < numD; i++) {
          if(DossiersMedicaux[i].getMedecin().getNum_id_pro()==id){
              return DossiersMedicaux[i].getMedecin();
          }
      }
      return null;
  }
  public void medecinGest(int id) throws DossierMedicalNotFoundException{
       Medecin med=getMedecin(id);
       if(med==null){
           throw new DossierMedicalNotFoundException();
       }
       int choix =med.consulterDossier();
       while(choix<3){
           choix =med.consulterDossier();
           Consultable c =new ConsulterPatientMed(DossiersMedicaux,id,numD,choix);
           c.consulterDossier();
       }
   }
   public void patientGest(int num)throws DossierMedicalNotFoundException{
       System.out.println("1.Consulter information personnel");
       int choix=scan.nextInt();
       if(choix==1){
           Consultable c=new ConsulterPatientId(DossiersMedicaux,num,numD);
           c.consulterDossier();
       }

   }
   public void supprimerDossier()throws DossierMedicalNotFoundException{
       System.out.println("Donner num de patient:");
       int numPat=scan.nextInt();
       System.out.println("Donner id medecin");
       int idMed=scan.nextInt();
       boolean found=false;
       int pos=0;
       for (int i = 0; i < numD ; i++) {
           if (DossiersMedicaux[i].getMedecin().getNum_id_pro() == idMed && DossiersMedicaux[i].getPatient().getNum_sec_soc() == numPat)
           {
               pos=i;
               found=true;
           }
       }
       if(found==false){
           throw new DossierMedicalNotFoundException();
       }
       for (int i = pos; i <numD; i++) {
           DossiersMedicaux[i]=DossiersMedicaux[i+1];
       }
       numD--;

   }
   public String afficher_dossiers() throws DossierMedicalNotFoundException{
       String dossiers="";
       if(numD==0){
           throw new DossierMedicalNotFoundException();
       }
       for (int i = 0; i < numD; i++) {
           dossiers+=DossiersMedicaux[i].toString();
       }
       return dossiers;
   }


}
