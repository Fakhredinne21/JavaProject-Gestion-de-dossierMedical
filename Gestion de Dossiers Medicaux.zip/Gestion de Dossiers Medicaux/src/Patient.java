import java.time.LocalDate;


public class Patient extends Utilisateur{
    private static int nump;
    private int num_sec_soc;
    private String ass_mal;

    public Patient(String nom, String prenom, LocalDate date_Naissance, int tlf, String adresse, String ass_mal) {
        super(nom, prenom, date_Naissance, tlf, adresse);
        nump++;
        this.num_sec_soc = nump;
        this.ass_mal = ass_mal;
    }

    @Override
    public String toString() {
        return "Patient{"+ super.toString() +
                "num_sec_soc=" + num_sec_soc +
                ", ass_mal='" + ass_mal + '\'' +
                "} " ;
    }

    public int getNum_sec_soc() {
        return num_sec_soc;
    }

    public void setNum_sec_soc(int num_sec_soc) {
        this.num_sec_soc = num_sec_soc;
    }

    public String getAss_mal() {
        return ass_mal;
    }

    public void setAss_mal(String ass_mal) {
        this.ass_mal = ass_mal;
    }
}
