import java.time.LocalDate;
import java.util.Scanner;

public class Medecin extends Utilisateur{
    private static int numM;
    private String Specialite;
    private int num_id_pro;

    public String getSpecialite() {
        return Specialite;
    }

    public void setSpecialite(String specialite) {
        Specialite = specialite;
    }

    public int getNum_id_pro() {
        return num_id_pro;
    }

    public void setNum_id_pro(int num_id_pro) {
        this.num_id_pro = num_id_pro;
    }

    public Medecin(String nom, String prenom, LocalDate date_Naissance, int tlf, String adresse, String specialite) {
        super(nom, prenom, date_Naissance, tlf, adresse);
        Specialite = specialite;
        numM++;
        this.num_id_pro = numM;
    }

    @Override
    public String toString() {
        return "Medecin{" +
                "Specialite='" + Specialite + '\'' +
                ", num_id_pro=" + num_id_pro +
                "} " + super.toString();
    }
    public int consulterDossier(){
        System.out.println("1.Consulter informations de votre patient");
        System.out.println("2.modifier les informations de traitement");
        System.out.println("3.Quitter");
        Scanner scan =new Scanner(System.in);
        int cho=scan.nextInt();
        return cho;
    }

}
