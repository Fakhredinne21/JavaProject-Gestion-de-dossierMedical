import java.util.Scanner;

public class ModifierDossier implements Modifiable{
    Scanner in = new Scanner(System.in);
    private DossierMedical[] dossierMedicals;
    private int num_soc;
    private int nbd;
    private int num_id_pro;

    public ModifierDossier(DossierMedical[] dossierMedicals, int num_soc, int nbd, int num_id_pro) {
        this.dossierMedicals = dossierMedicals;
        this.num_soc = num_soc;
        this.nbd = nbd;
        this.num_id_pro = num_id_pro;
    }

    private int menu_chang() {

        System.out.println("Effecter des changement sur le traitement");
        System.out.println("1. Ajouter symptomes");
        System.out.println("2. Ajouter diagnostics");
        System.out.println("3. Ajouter medicaments");
        System.out.println("4. Supprimer symptomes");
        System.out.println("5. Supprimer diagnostics");
        System.out.println("6. Supprimer medicaments");
        System.out.println("7. Quitter");
        int choix = in.nextInt();
        while (choix < 1 || choix > 7) {
            choix = in.nextInt();
        }
        return choix;
    }
    private void changement(int choix,int posPat){
        switch (choix) {
            case 1:
                String sys="";

                System.out.println("Ajouter une nouvelle symptome:");
                sys=in.nextLine();
                dossierMedicals[posPat].getSymptomes().add(sys);
                break;
            case 2:
                String diag="";
                System.out.println("Ajouter une nouvelle diagnostic:");
                diag=in.nextLine();
                dossierMedicals[posPat].getDiagnostics().add(diag);

                break;
            case 3:
                String medic="";
                System.out.println("Ajouter une nouvelle medicament:");
                medic=in.nextLine();
                dossierMedicals[posPat].getMedicaments().add(medic);
                break;

            case 4:
                String nom;
                System.out.println("Donner la nouvelle nom:");
                nom=in.nextLine();
                dossierMedicals[posPat].getPatient().setNom(nom);
                break;
            case 5:
                String prenom;
                in.nextLine();
                System.out.println("Donner la nouvelle prenom:");
                prenom=in.nextLine();
                dossierMedicals[posPat].getPatient().setPrenom(prenom);
                break;

            case 6:
                int num_soc;
                System.out.println("Donner la nouvelle Numéro de sécurité sociale:");
                num_soc=in.nextInt();
                dossierMedicals[posPat].getPatient().setNum_sec_soc(num_soc);
                break;
            case 7:
                return;

        }
    }
    @Override
    public void ModifierDossier() throws DossierMedicalNotFoundException{
        int posDoc=0;
        boolean exist=false;
        for (int i = 0; i < nbd&&!exist; i++) {
            if(dossierMedicals[i].getPatient().getNum_sec_soc()== num_soc&&dossierMedicals[i].getMedecin().getNum_id_pro()== num_id_pro)
            {posDoc=i;
            exist=true;}
        }
        if(exist!=true){
            throw new DossierMedicalNotFoundException();
        }
        int choix = menu_chang();
        while (choix < 7) {
            in.nextLine();
            changement(choix,posDoc);
            choix = menu_chang();
        }
        System.out.println("Fin  de changement");


    }
}
