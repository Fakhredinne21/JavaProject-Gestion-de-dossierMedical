import java.util.Scanner;

public class modifierMedecin implements Modifiable{
    Scanner in = new Scanner(System.in);
    private DossierMedical[] dossierMedicals;
    private int num_id_pro;
    private int nbd;

    public modifierMedecin(DossierMedical[] dossierMedicals, int num_id_pro, int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.num_id_pro = num_id_pro;
        this.nbd = nbd;
    }
    private int menu_chang() {

        System.out.println("Effecter des changement sur le medecin:");
        System.out.println("1. Changer specialite");
        System.out.println("2. Changer Numero de telephone");
        System.out.println("3. Changer Adresse");
        System.out.println("4. Changer nom");
        System.out.println("5. Changer prenom");
        System.out.println("6. Changer Identification personnel");
        System.out.println("7. Quitter");
        int choix = in.nextInt();
        while (choix < 1 || choix > 7) {
            choix = in.nextInt();
        }
        return choix;
    }
    private void changement(int choix,int posMed){
        switch (choix) {
            case 1:
                String spec;
                spec=in.nextLine();
                System.out.println("Donner la nouvelle specialite:");
                spec=in.nextLine();
                dossierMedicals[posMed].getMedecin().setSpecialite(spec);
                break;
            case 2:
                int num;
                System.out.println("Donner la nouvelle numero de tlf:");
                num=in.nextInt();
                dossierMedicals[posMed].getMedecin().setTlf(num);
                break;
            case 3:
                String add;
                in.nextLine();
                System.out.println("Donner la nouvelle addresse:");
                add=in.nextLine();
                dossierMedicals[posMed].getMedecin().setAdresse(add);
                break;

            case 4:
                String nom;
                in.nextLine();
                System.out.println("Donner la nouvelle nom:");
                nom=in.nextLine();
                dossierMedicals[posMed].getMedecin().setNom(nom);
                break;
            case 5:
                String prenom;
                in.nextLine();
                System.out.println("Donner la nouvelle prenom:");
                prenom=in.nextLine();
                dossierMedicals[posMed].getMedecin().setPrenom(prenom);
                break;

            case 6:
                int id;
                System.out.println("Donner la nouvelle numero de numero identification personnel:");
                id=in.nextInt();
                dossierMedicals[posMed].getMedecin().setNum_id_pro(id);

                break;
            case 7:
                return;

        }
    }
    @Override
    public void ModifierDossier() throws DossierMedicalNotFoundException{
        int posMed=0;
        boolean exist=false;
        for (int i = 0; i < nbd&&dossierMedicals[i].getMedecin().getNum_id_pro()==num_id_pro; i++) {
            posMed=i;
            exist=true;
        }
        if(exist!=true){
            throw new DossierMedicalNotFoundException();
        }
        int choix = menu_chang();
        while (choix < 7) {
            if(choix==1){
                changement(choix,posMed);
            }

            choix = menu_chang();
        }
        System.out.println("Fin  de changement");


    }
}
