import java.util.ArrayList;

public class DossierMedical implements Consultable{
    private Patient patient;
    private ArrayList symptomes;
    private  ArrayList diagnostics;
    private ArrayList medicaments;
    private Medecin medecin;

    public ArrayList getSymptomes() {
        return symptomes;
    }

    public ArrayList getDiagnostics() {
        return diagnostics;
    }

    public ArrayList getMedicaments() {
        return medicaments;
    }

    public DossierMedical(Patient patient, ArrayList symptomes, ArrayList diagnostics, ArrayList medicaments, Medecin medecin) {
        this.patient = patient;
        this.symptomes = symptomes;
        this.diagnostics = diagnostics;
        this.medicaments = medicaments;
        this.medecin = medecin;
    }

    @Override
    public void consulterDossier() {
        System.out.println(symptomes.toString()+diagnostics.toString()+medicaments.toString()+medecin.toString());

    }
    public void ajouterSymptome(String Symp){symptomes.add(Symp);}
    public void ajouterDiag(String Diag){
        diagnostics.add(Diag);
    }
    public void ajouterMedc(String Medc){medicaments.add(Medc);
    }

    @Override
    public String toString() {
        return "DossierMedical{" +
                "patient=" + patient +
                '}';
    }

    public Patient getPatient() {
        return patient;
    }
    public Medecin getMedecin() {
        return medecin;
    }

    public void setMedecin(Medecin medecin) {
        this.medecin = medecin;
    }


}
