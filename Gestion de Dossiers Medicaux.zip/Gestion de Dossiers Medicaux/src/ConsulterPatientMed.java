import java.util.Scanner;

public class ConsulterPatientMed implements Consultable{
    Scanner scan=new Scanner(System.in);
    private DossierMedical[] dossierMedicals;
    private int nbd;
    private int num_id_pro;
    private int choix;

    public ConsulterPatientMed(DossierMedical[] dossierMedicals, int nbd, int num_id_pro, int choix) {
        this.dossierMedicals = dossierMedicals;
        this.nbd = nbd;
        this.num_id_pro = num_id_pro;
        this.choix = choix;
    }
    @Override
    public void consulterDossier(){
        System.out.println("Donner numero de patient");
        int numPat=scan.nextInt();
        if(choix==1){
            Consultable c=new ConsulterPatientId(dossierMedicals,numPat,nbd);
            try {
                c.consulterDossier();

            }
            catch(DossierMedicalNotFoundException e){
                System.out.println(e.getMessage());
            }
        }
        if(choix==2){

            Modifiable md=new ModifierDossier(dossierMedicals,numPat,nbd,num_id_pro);
            try {
                md.ModifierDossier();
            }catch(DossierMedicalNotFoundException e){
                System.out.println(e.getMessage());
            }

        }

    }
}
