public class ConsulterListeMedecin implements Consultable{
    private DossierMedical[] dossierMedicals;
    private int nbd;

    public ConsulterListeMedecin(DossierMedical[] dossierMedicals, int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.nbd = nbd;
    }

    @Override
    public void consulterDossier() throws DossierMedicalNotFoundException {
        if (nbd==0){
            throw new DossierMedicalNotFoundException();
        }
        for (int i = 0; i < nbd; i++) {
            System.out.println(dossierMedicals[i].getMedecin().toString());
        }
    }
}
