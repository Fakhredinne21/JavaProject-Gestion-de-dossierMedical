public class ConsulterMedecinSpec implements Consultable{
    private DossierMedical[] dossierMedicals;
    private String spec;
    private int nbd;

    public ConsulterMedecinSpec(DossierMedical[] dossierMedicals, String spec, int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.spec = spec;
        this.nbd = nbd;
    }

    @Override
    public void consulterDossier() throws DossierMedicalNotFoundException {
        boolean found=false;
        for (int i = 0; i <nbd ; i++) {
            if (dossierMedicals[i].getMedecin().getSpecialite().equals(spec)){
                found=true;
                System.out.println(dossierMedicals[i].getMedecin().toString());
            }
        }
        if(found==false){
            throw new DossierMedicalNotFoundException();
        }
    }
}
