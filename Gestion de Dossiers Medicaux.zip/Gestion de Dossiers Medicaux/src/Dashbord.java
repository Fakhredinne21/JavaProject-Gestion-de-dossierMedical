import java.util.Scanner;

public class Dashbord {
    Scanner scan=new Scanner(System.in);
   GestionDossierMedicaux bd=new GestionDossierMedicaux(10);


    public static void main(String[] args) {
        new Dashbord().lancer();
    }

    private void gestionDossier(int choix) {


        switch (choix) {
            case 1:
                bd.creerDossierMedical();
                break;
            case 2:
                bd.consulterDossier();
                break;
            case 3:
                bd.modifierDossier();
                break;

            case 4:
                try {
                    bd.supprimerDossier();
                }catch(DossierMedicalNotFoundException e){
                    System.out.println(e.getMessage());
                }
                break;
            case 5:
                try {
                    System.out.println(bd.afficher_dossiers());
                }catch (DossierMedicalNotFoundException e){
                    System.out.println(e.getMessage());
                }
                break;

            case 6:
                lancer();
                break;
        }


    }
    private int menuAdmin() {
        Scanner in = new Scanner(System.in);

        System.out.println("Gestion des Dossiers medicaux");
        System.out.println("1. Ajouter Dossier");
        System.out.println("2. Consulter Dossier");
        System.out.println("3. Modifier Dossier");
        System.out.println("4. Supprimer Dossier");
        System.out.println("5. Afficher tous les dossiers");
        System.out.println("6. Quitter");
        int choix = in.nextInt();
        while (choix < 1 || choix > 6) {
            choix = in.nextInt();
            scan.nextLine();
        }
        return choix;
    }

    public void lancer() {
        Scanner in = new Scanner(System.in);
        System.out.println("Gestion des Dossiers medicaux");
        System.out.println("1. Login Patient");
        System.out.println("2. Login Medecin");
        System.out.println("3. Login Admin ");
        System.out.println("4. Quitter ");
        int choix = in.nextInt();
        while (choix < 1 || choix > 4) {
            choix = in.nextInt();
            scan.nextLine();
        }
        if(choix==1){
            System.out.println("Donner numero ");
            int num=scan.nextInt();
            boolean found =bd.loginPatient(num);
            if(found){
                try {
                    bd.patientGest(num);
                }catch(DossierMedicalNotFoundException e){
                    System.out.println(e.getMessage());
                }
            }
            else{
                System.out.println("Not found");
                lancer();
            }
        }
        if(choix==2){
            System.out.println("Donner numero id pro");
            int id=scan.nextInt();
            boolean found =bd.loginMedecin(id);
            if(found){
                try {
                    bd.medecinGest(id);
                }catch(DossierMedicalNotFoundException e){
                    System.out.println(e.getMessage());
                }
            }
            else{
                System.out.println("Not found");
                lancer();
            }

        }
        if (choix==3){
            choix = menuAdmin();
            while (choix < 7) {
                gestionDossier(choix);
                choix = menuAdmin();
            }
            System.out.println("Fin  programme");
        }
        if(choix==4){
            return;
        }

        }
}