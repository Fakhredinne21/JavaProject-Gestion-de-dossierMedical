import java.time.LocalDate;
public abstract class Utilisateur {
    private String nom;
    private String prenom;
    private LocalDate date_Naissance;
    private int tlf;
    private String Adresse;

    @Override
    public String toString() {
        return "nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", date_Naissance=" + date_Naissance +
                ", tlf=" + tlf +
                ", Adresse='" + Adresse + '\''
                ;
    }

    public Utilisateur(String nom, String prenom,LocalDate date ,int tlf, String adresse) {
        this.nom = nom;
        this.prenom = prenom;
        this.tlf = tlf;
        this.date_Naissance=date;
        Adresse = adresse;

    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public LocalDate getDate_Naissance() {
        return date_Naissance;
    }
    public int getTlf() {
        return tlf;
    }

    public void setTlf(int tlf) {
        this.tlf = tlf;
    }

    public String getAdresse() {
        return Adresse;
    }

    public void setAdresse(String adresse) {
        Adresse = adresse;
    }
}
