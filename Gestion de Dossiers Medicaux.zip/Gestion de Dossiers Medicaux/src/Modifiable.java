public interface Modifiable {
    public void ModifierDossier() throws DossierMedicalNotFoundException;
}
