public class ConsulterDossier implements Consultable{
    @Override
    public void consulterDossier() throws DossierMedicalNotFoundException {
        
    }


}
