public class ConsulterNomPatient implements Consultable{
    private DossierMedical[] dossierMedicals;
    private String nom;
    private int nbd;

    public ConsulterNomPatient(DossierMedical[] dossierMedicals, String nom,int nbd) {
        this.dossierMedicals = dossierMedicals;
        this.nom = nom;
        this.nbd=nbd;
    }

    @Override
    public void consulterDossier() throws DossierMedicalNotFoundException{

        boolean found=false;

        for (int i = 0; i <nbd ; i++) {
            if (dossierMedicals[i].getPatient().getPrenom().equals(nom)){
                found=true;
                System.out.println(dossierMedicals[i].getPatient().toString());
            }
        }
        if(found==false){
           throw new DossierMedicalNotFoundException();
        }


    }
}
